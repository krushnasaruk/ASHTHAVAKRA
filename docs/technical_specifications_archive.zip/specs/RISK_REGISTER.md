# RehabBridge NEXUS / H10 — Risk Register & Failure Mode Analysis

**Event:** Innovation 2K26, College of Engineering, Phaltan (3–4 November 2026)  
**Standard Reference:** IEC 62304 / ISO 14971 Risk Categorization adapted for Engineering Demonstrator  
**Status:** Grounded in codebase implementations and hardware fail-safes.

---

## 1. Subsystem Risk Matrix

| Risk ID | Hazard / Trigger | Impact | Severity | Likelihood | Software / Hardware Mitigation | Test Verification |
|---|---|---|---|---|---|---|
| **RSK-01** | USB cable snag or physical disconnect mid-attempt | Missing sensor packets during transfer | High | Medium | Monotonic `seq` tracker detects drop; state machine flags `STALE_SENSOR_PACKET` (>200ms) and emits honest `UNCERTAIN` verdict. Non-blocking reconnect loop resumes stream upon re-plug. | `tests/test_serial_ingest.py::test_si_06_reconnection_after_unplug`, `tests/test_taskproof.py::test_tp_10_device_disconnect_mid_attempt_yields_uncertain` |
| **RSK-02** | Camera lighting shift or hands occluding ArUco marker | Lost marker centroid in flight | High | High | Frame age tracker monitors occlusion; if occlusion > 150ms during `OBJECT_LIFTED`, state machine emits `MARKER_OCCLUDED` and awards `UNCERTAIN`. Never assumes object reached target blindly. | `tests/test_vision.py::test_vi_04_frame_age_calculation`, `tests/test_taskproof.py::test_tp_07_marker_occluded_during_lift_yields_uncertain` |
| **RSK-03** | FSR contact wire break or sensor railed to VDD/GND | False contact detection or silent failure | High | Low | FSR rail detector checks ADC counts $\in [50, 32700]$. Values outside rail trigger `FSR_FAULT` flag and lock verdict to `UNCERTAIN`. Spare FSR on hand for hot-swap. | `tests/test_signal.py::test_sg_08_fsr_rail_detection_yields_fsr_fault`, `tests/test_taskproof.py::test_tp_09_fsr_disconnected_mid_attempt_yields_uncertain` |
| **RSK-04** | Volunteer releases object before target zone | Incomplete transfer presented as verified | Critical | Medium | Deterministic guard `TARGET_REACHED` requires marker polygon membership in Zone B before release. Premature release emits `EARLY_RELEASE_OUTSIDE_TARGET` and marks `FAILED`. | `tests/test_taskproof.py::test_tp_03_release_before_target_arrival` |
| **RSK-05** | Object knocked or rolls after placement | Unstable transfer credited as stable | Medium | Medium | Stillness detector evaluates marker centroid displacement over 500ms post-release. If movement $> 6$ px, emits `OBJECT_DISTURBED_AFTER_RELEASE` and marks `FAILED`. | `tests/test_signal.py::test_sg_11_object_stillness_detector`, `tests/test_taskproof.py::test_tp_04_object_moved_after_release` |
| **RSK-06** | Database lock contention on concurrent writes | API freeze during trial recording | High | Low | SQLite configured explicitly with PRAGMA `journal_mode=WAL` (Write-Ahead Logging) and `busy_timeout=5000ms`, enabling non-blocking concurrent reads and single-writer safety. | `backend/database.py`, `tests/test_api_nexus.py::test_api_06_and_api_07_task_lifecycle_and_ground_truth_separation` |
| **RSK-07** | Sensor baseline drift due to glove re-donning | Incorrect normalized flexion span | Medium | High | Two-point calibration checks baseline open drift; if open value shifts $> 15\%$ of span, UI flags recalibration required. Minimum span check ($\ge 300$ ADC counts) rejects unresponsive sensors. | `backend/signal/calibration.py`, `tests/test_signal.py::test_sg_02_invalid_span_rejected` |
| **RSK-08** | Operator enters incorrect ground truth hotkey | Contaminated evaluation report | Low | Low | Database maintains strict separation between automated TaskProof verdict and operator ground truth label. Confusion matrix and raw timestamps preserved for audit. | `backend/models.py`, `backend/evaluation.py`, `tests/test_api_nexus.py` |
| **RSK-09** | Clinical misinterpretation of prototype scores | Volunteer or judge believes device diagnoses medical condition | Critical | Medium | Permanent non-medical disclaimer banner rendered across all screens; prohibited medical terminology enforced in code; outputs restricted to task verification and engineering metrics. | `frontend/src/App.tsx`, `mobile/lib/main.dart`, `docs/DECISIONS.md` (ADR 06 / D-11) |

